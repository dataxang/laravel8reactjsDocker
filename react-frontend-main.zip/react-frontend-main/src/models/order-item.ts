export class OrderItem {
    constructor(
        public id: number,
        public product_title: string,
        public price: number,
        public quantity: number
    ) {
    }
}
