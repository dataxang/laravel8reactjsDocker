export class Role {
    constructor(
        public id = 0,
        public name = ''
    ) {
    }
}
