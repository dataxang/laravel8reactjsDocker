export class Product {
    constructor(
        public id = 0,
        public title = '',
        public description = '',
        public image = '',
        public price = 0
    ) {
    }
}
